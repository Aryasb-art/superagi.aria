"""
AI Agents package for the FastAPI authentication system.
"""