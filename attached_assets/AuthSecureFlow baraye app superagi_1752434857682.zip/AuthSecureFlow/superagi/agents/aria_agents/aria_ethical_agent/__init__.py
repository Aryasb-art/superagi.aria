"""
Aria Ethical Agent - Advanced ethical reasoning and decision analysis agent.
"""

from .aria_ethical_agent import AriaEthicalAgent

__all__ = ["AriaEthicalAgent"]