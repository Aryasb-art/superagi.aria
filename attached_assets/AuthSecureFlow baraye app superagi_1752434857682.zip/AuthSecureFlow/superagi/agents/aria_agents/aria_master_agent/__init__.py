"""
Aria Master Agent - Central coordinator for managing and routing messages between AI agents.
"""

from .aria_master_agent import AriaMasterAgent

__all__ = ["AriaMasterAgent"]