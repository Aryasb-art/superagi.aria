"""
Aria Emotion Agent - Advanced emotion detection and regulation agent.
"""

from .aria_emotion_agent import AriaEmotionAgent

__all__ = ["AriaEmotionAgent"]