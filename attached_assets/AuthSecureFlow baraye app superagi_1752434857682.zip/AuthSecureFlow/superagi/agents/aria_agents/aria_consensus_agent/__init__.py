"""
Aria Consensus Agent - Collaborative decision-making simulation agent.
"""

from .aria_consensus_agent import AriaConsensusAgent

__all__ = ["AriaConsensusAgent"]