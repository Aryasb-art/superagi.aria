"""
Aria Repetitive Agent - Pattern detection agent that learns from repeated concepts.
"""

from .aria_repetitive_agent import AriaRepetitiveAgent

__all__ = ["AriaRepetitiveAgent"]