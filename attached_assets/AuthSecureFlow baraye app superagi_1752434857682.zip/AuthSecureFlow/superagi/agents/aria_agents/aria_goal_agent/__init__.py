"""
Aria Goal Agent - Advanced goal and intent detection agent with hybrid analysis.
"""

from .aria_goal_agent import AriaGoalAgent

__all__ = ["AriaGoalAgent"]